package br.edu.usj.ads.lpii.sellbook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SellbookApplication {

	public static void main(String[] args) {
		SpringApplication.run(SellbookApplication.class, args);
	}

}
